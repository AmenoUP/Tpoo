# Changelog

## 0.1.3 (2024-02-02)
  * Support OTP 24

## 0.1.2 (2024-01-08)
  * Use `:inet_res.getbyname/2` to resolve the given hostname to support search list for host-name lookup, such as in k8s and similar setups

## 0.1.1 (2023-09-27)
  * Fix bug where an empty clauses would raise an argument error

## 0.1.0 (2023-07-11)
  * Initial release